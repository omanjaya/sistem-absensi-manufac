# Panduan Deployment Sistem Absensi ke Hostinger

## Persyaratan Hostinger

### 1. Paket Hosting yang Direkomendasikan

- **Business Web Hosting** atau **Cloud Hosting** (minimum)
- PHP 8.2 atau lebih tinggi
- MySQL database support
- SSH access (untuk deployment yang mudah)
- SSL Certificate (Let's Encrypt tersedia gratis)

### 2. Spesifikasi Teknis yang Dibutuhkan

- **Memory**: Minimum 1GB RAM
- **Storage**: Minimum 5GB space
- **PHP Version**: 8.2+
- **Database**: MySQL 5.7+ atau MariaDB
- **Node.js**: 18+ (untuk build frontend)

## Langkah-langkah Deployment

### Langkah 1: Persiapan Domain dan Hosting

1. **Setup Domain di Hostinger**

   ```
   Domain: manufac.id
   Subdomain: www.manufac.id (opsional)
   ```

2. **Aktifkan SSL Certificate**
   - Masuk ke hPanel Hostinger
   - Pilih domain manufac.id
   - Aktifkan SSL/TLS Certificate (gratis Let's Encrypt)

### Langkah 2: Setup Database

1. **Buat Database MySQL**

   ```
   Database Name: u123456789_absensi
   Username: u123456789_admin
   Password: [Generate strong password]
   ```

2. **Update .env.production**
   ```env
   DB_CONNECTION=mysql
   DB_HOST=localhost
   DB_PORT=3306
   DB_DATABASE=u123456789_absensi
   DB_USERNAME=u123456789_admin
   DB_PASSWORD=YourActualPassword
   ```

### Langkah 3: Persiapan File untuk Upload

#### A. Build Frontend Vue.js

```bash
cd frontend-web
cp .env.production .env
npm install
npm run build:production
```

#### B. Prepare Laravel Backend

```bash
cd backend-api
cp .env.production .env
# Update dengan database credentials yang sebenarnya
composer install --no-dev --optimize-autoloader
php artisan key:generate
```

### Langkah 4: Upload ke Hostinger

#### Metode 1: File Manager (Recommended untuk pemula)

1. **Upload Frontend (Vue.js)**

   - Buka File Manager di hPanel
   - Navigate ke `public_html/`
   - Upload semua file dari `frontend-web/dist/` ke root directory
   - Pastikan `index.html` ada di root

2. **Upload Backend (Laravel)**
   - Buat folder `api/` di dalam `public_html/`
   - Upload semua file Laravel ke `public_html/api/`
   - Pindahkan `public_html/api/public/*` ke `public_html/api/`

#### Metode 2: Git Deployment (Advanced)

```bash
# Clone repository di Hostinger via SSH
git clone [your-repo-url] /path/to/site
cd /path/to/site

# Setup backend
cd backend-api
composer install --no-dev --optimize-autoloader
cp .env.production .env
php artisan key:generate
php artisan migrate --force
php artisan config:cache
php artisan route:cache
php artisan view:cache

# Setup frontend
cd ../frontend-web
npm ci --production
npm run build:production
cp -r dist/* /path/to/public_html/
```

### Langkah 5: Konfigurasi Server

#### A. Update .htaccess untuk Laravel API

Buat file `public_html/api/.htaccess`:

```apache
<IfModule mod_rewrite.c>
    RewriteEngine On

    # Handle Authorization Header
    RewriteCond %{HTTP:Authorization} .
    RewriteRule .* - [E=HTTP_AUTHORIZATION:%{HTTP:Authorization}]

    # Redirect Trailing Slashes If Not A Folder
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteCond %{REQUEST_URI} (.+)/$
    RewriteRule ^ %1 [L,R=301]

    # Send Requests To Front Controller
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteRule ^ index.php [L]
</IfModule>
```

#### B. Update .htaccess untuk Frontend

Buat file `public_html/.htaccess`:

```apache
<IfModule mod_rewrite.c>
    RewriteEngine On

    # API Routes
    RewriteRule ^api/(.*)$ /api/index.php [L,QSA]

    # Vue.js SPA
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule ^(.*)$ /index.html [L,QSA]
</IfModule>

# Security Headers
<IfModule mod_headers.c>
    Header always set X-Frame-Options "SAMEORIGIN"
    Header always set X-Content-Type-Options "nosniff"
    Header always set X-XSS-Protection "1; mode=block"
    Header always set Referrer-Policy "strict-origin-when-cross-origin"
</IfModule>

# Cache Control
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType text/css "access plus 1 year"
    ExpiresByType application/javascript "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType image/jpg "access plus 1 year"
    ExpiresByType image/jpeg "access plus 1 year"
    ExpiresByType image/gif "access plus 1 year"
    ExpiresByType image/svg+xml "access plus 1 year"
</IfModule>
```

### Langkah 6: Final Setup

1. **Run Database Migration**

   ```bash
   cd public_html/api
   php artisan migrate --force
   php artisan db:seed --force
   ```

2. **Set Permissions**

   ```bash
   chmod -R 755 storage/
   chmod -R 755 bootstrap/cache/
   ```

3. **Test Endpoints**
   - Frontend: https://manufac.id/
   - API: https://manufac.id/api/
   - Login: https://manufac.id/api/login

## Konfigurasi Email (Opsional)

Jika ingin menggunakan fitur email:

```env
MAIL_MAILER=smtp
MAIL_HOST=smtp.hostinger.com
MAIL_PORT=587
MAIL_USERNAME=admin@manufac.id
MAIL_PASSWORD=YourEmailPassword
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS="admin@manufac.id"
MAIL_FROM_NAME="Sistem Absensi Manufac"
```

## Troubleshooting

### 1. Error 500 Internal Server Error

- Cek file permissions (storage/, bootstrap/cache/)
- Pastikan .env file ada dan konfigurasi benar
- Cek error logs di hPanel

### 2. Database Connection Error

- Pastikan credentials database benar
- Cek apakah database sudah dibuat
- Pastikan user database punya permission

### 3. API Routes Tidak Bekerja

- Cek .htaccess file
- Pastikan mod_rewrite aktif
- Cek struktur folder

### 4. Frontend Tidak Load

- Pastikan index.html ada di root
- Cek build process Vue.js
- Cek browser console untuk errors

## Maintenance & Updates

### Update Aplikasi

```bash
# Backup database
mysqldump -u username -p database_name > backup.sql

# Pull latest changes
git pull origin main

# Update dependencies
composer install --no-dev --optimize-autoloader
npm ci --production && npm run build:production

# Run migrations
php artisan migrate --force

# Clear cache
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

### Monitoring

- Setup uptime monitoring
- Monitor disk space
- Check error logs regularly
- Setup automated backups

## Biaya Estimasi

### Hostinger Business Plan

- **Monthly**: ~$3.99/month
- **Annual**: ~$2.99/month (hemat 25%)

### Includes:

- 100GB SSD storage
- Unlimited bandwidth
- Free SSL certificate
- Daily backups
- Email accounts
- PHP 8.2+ support
- MySQL databases

## Support

Jika mengalami masalah deployment:

1. Cek documentation Hostinger
2. Contact Hostinger support (24/7)
3. Review error logs di hPanel
4. Test di local environment terlebih dahulu

---

**Note**: Panduan ini diasumsikan menggunakan Hostinger Business plan atau higher. Untuk shared hosting basic, beberapa fitur mungkin terbatas.
